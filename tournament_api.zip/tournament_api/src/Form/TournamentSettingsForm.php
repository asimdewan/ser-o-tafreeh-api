<?php

namespace Drupal\tournament_api\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;




/**
 * 
 * Tourment Setting Form
 */
class TournamentSettingsForm extends ConfigFormBase{
    
    /**
   * Config settings.
   *
   * @var string
   */
  const SETTINGS = 'tournament_api.tournament_setting';
  
  /**
   * {@inheritdoc}
   */
  public function getFormid() {
    return 'tournament_api_admin_setting';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      static::SETTINGS,
    ];
  }
  public function buildForm(array $form, FormStateInterface  $form_state){
    $config = $this->config(static::SETTINGS);

    $form['tournament_api'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Tournament API'),
      '#default_value' => $config->get('tournament_api'),
    ];

  /*   $form['tournament_client_id'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Tournament Client ID'),
      '#default_value' => $config->get('tournament_client_id'),
    ];

    $form['tournament_secret'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Tournament Secret'),
      '#default_value' => $config->get('tournament_secret'),
    ]; */
    
    $form['api_username'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Username'),
      '#default_value' => $config->get('api_username'),
    ];
    $form['api_password'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Password'),
      '#default_value' => $config->get('api_password'),
    ];
    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Retrieve the configuration.
    $this->configFactory->getEditable(static::SETTINGS)
      ->set('tournament_api', $form_state->getValue('tournament_api'))
      ->set('api_username', $form_state->getValue('api_username'))
      ->set('api_password', $form_state->getValue('api_password'))
      ->save();

    parent::submitForm($form, $form_state);
  }
}
