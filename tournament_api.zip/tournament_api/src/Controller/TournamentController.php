<?php

/* namespace Drupal\bs_global\Controller; */

namespace Drupal\tournament_api\Controller; 

use DateTime;
use DateTimeZone;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Url;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\Node\NodeInterface;
use Drupal\Core\Form\ConfigFormBase;
use Symfony\Component\HttpFoundation\Request;
// use Drupal\bs_silverbyte_api\utills\ApiFactory;
use Drupal\taxonomy\Entity\Term;
// use LanguageDetector\LanguageDetector;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\node\Entity\Node;
use Drupal\Core\Database\Database;

use Drupal\Component\Serialization\Json;

use GuzzleHttp\Exception\ConnectException;


use \GuzzleHttp\Exception\RequestException;
use Symfony\Component\HttpFoundation\Response;


/**
 * Redirect to My Properties Page.
 */
class TournamentController extends ControllerBase {
/**
     * Loads the page
     */
    public static function content() {


      /* Curl Request START */
      try{
        $api_resp_data2 = [];
        // $user = \Drupal::currentUser()->id();
        $client2 = \Drupal::httpClient();
        $api_request2 = $client2->request('GET', 'http://test.psd2htmldesign.com/tournament-api/sample_tournament.json', [
            'auth' => [
                "dev",
                "dev"
            ],
            'connect_timeout' => 3,
            'http_errors' =>  false,
        ]);
        $status_code2 = $api_request2->getStatusCode();
    
        if ($status_code2 == 200) {

         $body2 = json_decode($api_request2->getBody()->getContents());
         if (!empty($body2)) {
             $api_resp_data2 = $body2;
         }
         
          //  $available_data = \Drupal\node\Entity\Node::load($result);$item->id

          $html_node_data_get_results = '<div class="tournament-table-wrapper">
          <table border="0" cellpadding="0" cellspacing="0" style="width: 1110px;">
            <thead>
              <tr>
                <th scope="col">Rank</th>
                <th scope="col">First</th>
                <th scope="col">Last</th>
                <th scope="col">Player ID</th>
                <th scope="col">Score</th>
                <th scope="col">Free Play</th>
              </tr>
            </thead>
            <tbody>';
          $propertyId = 7471;
          $node_property = Node::load($propertyId);
          if(count($api_resp_data2)>0 && isset($api_resp_data2) && isset($node_property)){
            foreach ($api_resp_data2 as $key=>&$item) {
            /* Our Code START */
              $html_node_data_get_results .= 
              "<tr>
                <td>".$item->rank_fld."</td>
                <td>".$item->first_fld."</td>
                <td>".$item->last_fld."</td>
                <td>".$item->played_id_fld."</td>
                <td>".$item->score_fld."</td>
                <td>".$item->free_play_fld."</td>
              </tr>";
            }
            // $node_property->set('body',$html_node_data_get_results);
            // $node_property->body->format = 'full_html';
            // $node_property->field_paragraph_components->entity = $html_node_data_get_results;

            $html_node_data_get_results .= '</tbody></table></div>';
            $paragraph = Paragraph::create([
              'type' => 'wysiwyg',   // paragraph type machine name
              'field_header' => [   // paragraph's field machine name
                  'value' => 'Tournament Results'       // body text format
              ],
              'field_wysiwyg_description' => [   // paragraph's field machine name
                  'value' => $html_node_data_get_results,                  // body field value
                  'format' => 'full_html'         // body text format
              ]
            ]);
            // $paragraph_img = Paragraph::create($paragraph_id);
            // $paragraph_img->field_image[] = [
            //   'target_id' => $fid,
            //   'alt' => $alt,
            //   'title' => $title,
            // ];
            // $paragraph_img->save();
  
          $paragraph->save();
  
          $paragraph_items[] = [
            'target_id' => $paragraph->id(),
            'target_revision_id' => $paragraph->getRevisionId(),
          ];
  /* 
          $entity = Node::create($nodeData);
          $entity->save(); */
          $node_property->set('field_paragraph_components', $paragraph_items);

            // $node_property->set('field_paragraph_components',$html_node_data_get_results);
            // $node_property->field_paragraph_components->format = 'full_html';
            
            $node_property->save();
          }
          //return new RedirectResponse('/tournament-results');
          
          return new Response(
            'There are no jobs in the database', 
             Response::HTTP_OK
        );
          /* Our code end */
        }
      }
      catch (RequestException $e) {
        \Drupal::logger('tournament_api')->error('API is not working correctly.'.' ' . $e->getMessage());
      }
    }
    

    /* Curl Request END */












    //   $fileName = 'http://local-dev-yaamava.com/dev-api/sample_tournament.json';
    //   $json = file_get_contents($fileName);
    //   $jsonValues = json_decode($json, true);
    //   $html_node_data_get_results = "<table width='100%' border='1' >
    //   <tr>
    //    <th style='text-align: center;'>Rank</th>
    //    <th style='text-align: center;'>First</th>
    //    <th style='text-align: center;'>Rank</th>
    //    <th style='text-align: center;'>First</th>
    //    <th style='text-align: center;'>Rank</th>
    //    <th style='text-align: center;'>First</th>
    //   </tr>";
    //   $propertyId = 7461;
    //   $node_property = Node::load($propertyId);

    //   if(count($jsonValues)>0 && isset($jsonValues)){
    //      foreach ($jsonValues as $jsonValue) {
    //       $html_node_data_get_results .= 
    //         "<tr>
    //           <td style='text-align: center;'>".$jsonValue['rank_fld']."</td>
    //           <td style='text-align: center;'>".$jsonValue['first_fld']."</td>
    //           <td style='text-align: center;'>".$jsonValue['last_fld']."</td>
    //           <td style='text-align: center;'>".$jsonValue['played_id_fld']."</td>
    //           <td style='text-align: center;'>".$jsonValue['score_fld']."</td>
    //           <td style='text-align: center;'>".$jsonValue['free_play_fld']."</td>
    //         </tr>";
    //     } 
    //     $node_property->set('body',$html_node_data_get_results);
    //     $node_property->body->format = 'full_html';
    //     $html_node_data_get_results .= '</table>';
    //     $node_property->save();
    //     // return $this->redirect(); 
    //     return new RedirectResponse('/get-tournament-results-api');
        
    //   }
    // }
}